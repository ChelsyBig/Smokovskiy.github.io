export {};
declare global { interface Window { Telegram?: { WebApp: { ready():void; expand():void; close():void; colorScheme?: 'light'|'dark'; initData?: string; initDataUnsafe?: unknown; HapticFeedback?: { impactOccurred(style:'light'|'medium'|'heavy'):void }; MainButton?: { setText(t:string):void; show():void; hide():void }; } } } }
