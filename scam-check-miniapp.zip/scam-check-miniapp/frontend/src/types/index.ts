export type UserStatus = 'unknown'|'verified'|'guarantor'|'deputy'|'worker'|'suspicious'|'scammer'|'mailing';
export type DbUser = { id:number; username:string|null; telegramId:string; status:UserStatus; avatarUrl?:string; reason:string; addedAt:string; addedBy:string; description?:string };
export type Stats = { total:number; verified:number; guarantors:number; scammers:number; suspicious:number; mailing:number };
export type SearchResponse = { found:boolean; user?:DbUser; message?:string };
