import { useState } from 'react';
import { X } from 'lucide-react';
import { api } from '../api/client';
export function ReportModal({ target, onClose }: { target:string; onClose:()=>void }) {
  const [form, setForm] = useState({ target, reason:'', evidence:'', comment:'' });
  const [sent, setSent] = useState(false);
  const submit = async (e: React.FormEvent) => { e.preventDefault(); await api.report(form); setSent(true); window.Telegram?.WebApp.HapticFeedback?.impactOccurred('medium'); };
  return <div className="modalBackdrop"><div className="modal glass pop">
    <button className="iconBtn close" onClick={onClose}><X size={20}/></button>
    <h2>Жалоба</h2>{sent ? <div className="success">Жалоба отправлена на проверку.</div> :
    <form onSubmit={submit} className="form">
      <input value={form.target} onChange={e=>setForm({...form,target:e.target.value})} placeholder="username/ID" required />
      <input value={form.reason} onChange={e=>setForm({...form,reason:e.target.value})} placeholder="Причина" required />
      <input value={form.evidence} onChange={e=>setForm({...form,evidence:e.target.value})} placeholder="Доказательства/ссылка" />
      <textarea value={form.comment} onChange={e=>setForm({...form,comment:e.target.value})} placeholder="Комментарий" />
      <button className="redBtn">Отправить</button>
    </form>}
  </div></div>;
}
