import type { UserStatus } from '../types';
const map: Record<UserStatus, {label:string; cls:string}> = {
  unknown:{label:'Неизвестный',cls:'unknown'}, verified:{label:'Проверенный',cls:'good'}, guarantor:{label:'Гарант',cls:'gold'}, deputy:{label:'Заместитель',cls:'blue'}, worker:{label:'Работник',cls:'gray'}, suspicious:{label:'Сомнительный',cls:'warn'}, scammer:{label:'Скаммер',cls:'bad'}, mailing:{label:'Рассылка',cls:'pink'}
};
export function StatusBadge({ status }: { status: UserStatus }) { const s = map[status]; return <span className={`status ${s.cls}`}>{s.label}</span>; }
export const statusLabel = (status: UserStatus) => map[status].label;
