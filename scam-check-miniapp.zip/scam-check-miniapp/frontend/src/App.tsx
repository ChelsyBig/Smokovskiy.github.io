import { useEffect, useMemo, useState } from 'react';
import { AlertTriangle, Check, Crown, Moon, Search, ShieldCheck, Sun, X } from 'lucide-react';
import { api } from './api/client';
import type { DbUser, SearchResponse, Stats } from './types';
import { ReportModal } from './components/ReportModal';
import { StatusBadge, statusLabel } from './components/StatusBadge';
import './styles.css';

const unknownMessage = 'Пользователь неизвестный. Рекомендуем использовать проверенных гарантов в сделке.';

function ProfileCard({ user }: { user: DbUser }) {
  return <section className="profile glass fadeIn">
    <img className="avatar" src={user.avatarUrl || `https://api.dicebear.com/8.x/initials/svg?seed=${user.username || user.telegramId}`} />
    <h1>{user.username ? `@${user.username}` : user.telegramId}</h1>
    <p className="muted">ID: {user.telegramId}</p>
    <StatusBadge status={user.status}/>
    <div className="infoBox">
      <b>{statusLabel(user.status)}</b>
      <p>{user.description || user.reason}</p>
      <small>Добавлен: {new Date(user.addedAt).toLocaleDateString('ru-RU')} • {user.addedBy}</small>
    </div>
  </section>;
}

function StatsGrid({ stats }: { stats: Stats | null }) {
  const items = [
    ['Всего в базе', stats?.total ?? 0, <ShieldCheck/>], ['Проверенные', stats?.verified ?? 0, <Check/>],
    ['Гаранты', stats?.guarantors ?? 0, <Crown/>], ['Скаммеры', stats?.scammers ?? 0, <X/>],
    ['Сомнительные', stats?.suspicious ?? 0, <AlertTriangle/>], ['Рассылка', stats?.mailing ?? 0, <Search/>]
  ];
  return <section className="stats">{items.map(([t,v,icon],i)=><div className="stat glass" key={String(t)} style={{animationDelay:`${i*55}ms`}}><span>{icon}</span><b>{v}</b><small>{t}</small></div>)}</section>;
}

export default function App() {
  const [theme,setTheme] = useState<'dark'|'light'>('dark');
  const [query,setQuery] = useState('');
  const [result,setResult] = useState<SearchResponse | null>(null);
  const [stats,setStats] = useState<Stats | null>(null);
  const [loading,setLoading] = useState(false);
  const [report,setReport] = useState(false);
  const target = useMemo(() => result?.user?.username ? `@${result.user.username}` : query, [result,query]);
  useEffect(()=>{ window.Telegram?.WebApp.ready(); window.Telegram?.WebApp.expand(); api.stats().then(setStats).catch(console.error); },[]);
  useEffect(()=>{ document.documentElement.dataset.theme = theme; },[theme]);
  async function search(e?: React.FormEvent) { e?.preventDefault(); if (!query.trim()) return; setLoading(true); try { setResult(await api.search(query.trim())); } finally { setLoading(false); } }
  return <main className="app">
    <div className="blob one"/><div className="blob two"/>
    <header><div><p className="mini">Telegram Mini App</p><h1>ScamCheck Base</h1><span>Система проверки репутации</span></div><button className="iconBtn" onClick={()=>setTheme(theme==='dark'?'light':'dark')}>{theme==='dark'?<Sun/>:<Moon/>}</button></header>
    <form className="search glass" onSubmit={search}><Search size={20}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Введите @username или Telegram ID"/><button disabled={loading}>{loading?'...':'Найти'}</button></form>
    <StatsGrid stats={stats}/>
    {result?.found && result.user && <ProfileCard user={result.user}/>} 
    {result && !result.found && <section className="unknown glass fadeIn"><StatusBadge status="unknown"/><p>«{unknownMessage}»</p></section>}
    <button className="redBtn report" onClick={()=>setReport(true)}>Пожаловаться</button>
    <footer className="bottom glass"><div><b>Безопасная сделка</b><p>Проверяйте пользователей перед оплатой.</p></div><Crown/></footer>
    {report && <ReportModal target={target} onClose={()=>setReport(false)}/>} 
  </main>;
}
