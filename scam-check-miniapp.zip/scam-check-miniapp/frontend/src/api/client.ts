import type { SearchResponse, Stats } from '../types';
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:4000/api';
async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_URL}${path}`, { headers: { 'Content-Type': 'application/json' }, ...options });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}
export const api = {
  stats: () => request<Stats>('/stats'),
  search: (query: string) => request<SearchResponse>(`/users/search?q=${encodeURIComponent(query)}`),
  report: (payload: { target:string; reason:string; evidence:string; comment:string }) => request<{ok:boolean; id:number}>('/reports', { method:'POST', body: JSON.stringify(payload) })
};
