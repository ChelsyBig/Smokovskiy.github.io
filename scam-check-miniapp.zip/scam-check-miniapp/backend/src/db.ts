import Database from 'better-sqlite3';
export const db = new Database('scamcheck.sqlite');
db.exec(`CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE,
  telegram_id TEXT UNIQUE NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('unknown','verified','guarantor','deputy','worker','suspicious','scammer','mailing')),
  avatar_url TEXT, reason TEXT NOT NULL, description TEXT,
  added_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, added_by TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT, target TEXT NOT NULL, reason TEXT NOT NULL,
  evidence TEXT, comment TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);`);
const count = db.prepare('SELECT COUNT(*) as c FROM users').get() as {c:number};
if (count.c === 0) {
  const insert = db.prepare(`INSERT INTO users(username,telegram_id,status,avatar_url,reason,description,added_by) VALUES(?,?,?,?,?,?,?)`);
  insert.run('meksican','5001002','guarantor','https://api.dicebear.com/8.x/adventurer/svg?seed=meksican','Проверенный гарант чата','Провёл несколько сделок без жалоб.','@admin');
  insert.run('Diego_Squad','64030689','scammer','https://api.dicebear.com/8.x/adventurer/svg?seed=diego','Скам','Получены жалобы и подтверждающие материалы.','@moderator');
  insert.run('good_seller','78124590','verified',null,'Проверен администрацией','Без негативных отметок.','@admin');
  insert.run('risk_trade','91230001','suspicious',null,'Отказ от гарантов','Рекомендуется проводить сделки только через гаранта.','@moderator');
  insert.run('ads_bot','777111222','mailing',null,'Массовая рассылка','Автоматическая рекламная активность.','system');
}
