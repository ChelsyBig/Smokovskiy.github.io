import express from 'express';
import cors from 'cors';
import { z } from 'zod';
import { db } from './db.js';
const app = express();
app.use(cors()); app.use(express.json());
const normalize = (q:string) => q.trim().replace(/^@/,'');
app.get('/api/health',(_,res)=>res.json({ok:true}));
app.get('/api/stats',(_,res)=>{
  const total = (db.prepare('SELECT COUNT(*) c FROM users').get() as any).c;
  const by = (s:string)=>(db.prepare('SELECT COUNT(*) c FROM users WHERE status=?').get(s) as any).c;
  res.json({ total, verified:by('verified'), guarantors:by('guarantor'), scammers:by('scammer'), suspicious:by('suspicious'), mailing:by('mailing') });
});
app.get('/api/users/search',(req,res)=>{
  const q = normalize(String(req.query.q || ''));
  if (!q) return res.status(400).json({error:'q is required'});
  const row = db.prepare(`SELECT id, username, telegram_id telegramId, status, avatar_url avatarUrl, reason, description, added_at addedAt, added_by addedBy FROM users WHERE lower(username)=lower(?) OR telegram_id=?`).get(q,q);
  if (!row) return res.json({found:false,message:'Пользователь неизвестный. Рекомендуем использовать проверенных гарантов в сделке.'});
  res.json({found:true,user:row});
});
const reportSchema = z.object({ target:z.string().min(2), reason:z.string().min(2), evidence:z.string().optional().default(''), comment:z.string().optional().default('') });
app.post('/api/reports',(req,res)=>{
  const data = reportSchema.parse(req.body);
  const info = db.prepare('INSERT INTO reports(target,reason,evidence,comment) VALUES(?,?,?,?)').run(data.target,data.reason,data.evidence,data.comment);
  res.json({ok:true,id:info.lastInsertRowid});
});
const port = Number(process.env.PORT || 4000); app.listen(port,()=>console.log(`API http://localhost:${port}`));
