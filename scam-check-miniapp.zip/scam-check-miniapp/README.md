# ScamCheck Telegram Mini App

Современный Telegram Mini App для проверки пользователей на скам: React + TypeScript + Vite, Telegram WebApp SDK, Node.js + Express, SQLite.

## Запуск

```bash
npm install
npm run dev
```

Frontend: http://localhost:5173  
Backend API: http://localhost:4000/api

Для Telegram BotFather укажите HTTPS URL фронтенда. Для локальной проверки можно использовать ngrok/cloudflared.

## ENV

`frontend/.env`:
```env
VITE_API_URL=http://localhost:4000/api
```

## Структура базы

```sql
users(id, username, telegram_id, status, avatar_url, reason, description, added_at, added_by)
reports(id, target, reason, evidence, comment, created_at)
```

Статусы: `unknown`, `verified`, `guarantor`, `deputy`, `worker`, `suspicious`, `scammer`, `mailing`.
